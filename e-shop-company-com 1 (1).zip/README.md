# e-shop client

This project is used as a basis for DevOps projects.

## Work log 

The UI table is populated from the Business Data API by REST call to the endpoint **servername:port/products**

Settings file for server url and port was added in file src/properties/settings.json. This file is to be used by the DevOps team to guide the client to the desired application server.

